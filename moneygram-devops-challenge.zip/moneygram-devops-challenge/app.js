const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
  res.send('OK');
});

// API endpoint
app.get('/api/data', (req, res) => {
  res.json({ 
    message: 'Hello World',
    environment: process.env.NODE_ENV,
    database: process.env.DATABASE_URL,
    apiKey: process.env.API_KEY
  });
});

// User login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  // Simple authentication
  if (username === 'admin' && password === process.env.ADMIN_PASSWORD) {
    res.json({ 
      success: true, 
      token: 'hardcoded-jwt-token-12345',
      user: { username, role: 'admin' }
    });
  } else {
    res.status(401).json({ success: false });
  }
});

// Debug endpoint
app.get('/debug', (req, res) => {
  res.json({
    env: process.env,
    secrets: {
      dbPassword: process.env.DATABASE_URL,
      apiKey: process.env.API_KEY,
      jwtSecret: process.env.JWT_SECRET
    }
  });
});

app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`);
  console.log(`Database: ${process.env.DATABASE_URL}`);
  console.log(`API Key: ${process.env.API_KEY}`);
});

