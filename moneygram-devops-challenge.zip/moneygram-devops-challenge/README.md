# DevOps Take-Home Challenge

## Overview
You've inherited a Node.js application with an existing CI/CD pipeline and deployment setup. However, the previous DevOps engineer left several issues and inefficiencies that need to be addressed.

## Your Mission
Review the provided files and infrastructure configuration, identify all issues, and fix them. Document your changes and reasoning.

## Time Limit
**2-3 hours** (we respect your time - don't spend more than this)

## What You'll Find
- `.gitlab-ci.yml` - CI/CD pipeline configuration
- `Dockerfile` - Container configuration
- `docker-compose.yml` - Local development setup
- `app.js` - Simple Node.js application
- `package.json` - Dependencies

## What We're Looking For

### 1. Security Issues (HIGH PRIORITY)
- Identify and fix all security vulnerabilities
- Implement proper secrets management
- Apply security best practices

### 2. Performance & Optimization
- Optimize Docker image size
- Improve build times
- Reduce resource usage

### 3. Reliability & Best Practices
- Fix any broken or inefficient CI/CD configurations
- Implement proper error handling
- Add missing health checks and monitoring

### 4. Documentation
- Document all issues you found
- Explain your fixes and why you made them
- Provide recommendations for further improvements

## Deliverables

Please submit:

1. **Fixed Files** - All corrected configuration files
2. **CHANGES.md** - A document listing:
   - Each issue you identified (categorized by severity)
   - Your solution
   - Why it matters
3. **RECOMMENDATIONS.md** - Additional improvements you'd suggest if you had more time

## Evaluation Criteria

- **Security awareness** (30%)
- **DevOps best practices** (25%)
- **Problem identification skills** (20%)
- **Documentation quality** (15%)
- **Performance optimization** (10%)

## Bonus Points

- Set up monitoring/alerting strategy
- Implement multi-environment deployment strategy
- Add automated testing improvements
- Suggest cost optimization strategies
- Implement rollback mechanism

## Questions?

If anything is unclear, make reasonable assumptions and document them in your submission.

## Submission

Create a Git repository with your fixes and email us the link, or send a ZIP file with all files.

Good luck! 🚀

